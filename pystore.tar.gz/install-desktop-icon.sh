#!/usr/bin/env bash
# Run this ONCE (after ./build-desktop-app.sh). It creates a real desktop/
# app-menu icon that launches PyStore as a native app window.

set -e

SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
APPRUN="$SCRIPT_DIR/electron/dist/pystore-app/AppRun"

chmod +x "$SCRIPT_DIR/install-desktop-icon.sh"

if [ ! -f "$APPRUN" ]; then
    echo "❌ No built desktop app found at $APPRUN"
    echo "   Run ./build-desktop-app.sh first, then run this script again."
    exit 1
fi
chmod +x "$APPRUN"

APPS_DIR="$HOME/.local/share/applications"
DESKTOP_DIR="${XDG_DESKTOP_DIR:-$HOME/Desktop}"
mkdir -p "$APPS_DIR"

DESKTOP_FILE_CONTENT="[Desktop Entry]
Type=Application
Name=PyStore
GenericName=Linux App Store
Comment=Browse, install, and manage Linux apps
Exec=${APPRUN}
Path=${SCRIPT_DIR}
Icon=${SCRIPT_DIR}/electron/icon.png
Terminal=false
Categories=System;PackageManager;Utility;
StartupNotify=true
"

# Install into the application menu (this is what makes it show up when you
# search your app launcher / activities screen)
echo "$DESKTOP_FILE_CONTENT" > "$APPS_DIR/pystore.desktop"
chmod +x "$APPS_DIR/pystore.desktop"

# Also drop a copy on the Desktop, if one exists
if [ -d "$DESKTOP_DIR" ]; then
    echo "$DESKTOP_FILE_CONTENT" > "$DESKTOP_DIR/pystore.desktop"
    chmod +x "$DESKTOP_DIR/pystore.desktop"
    # GNOME/Nautilus marks new .desktop files "untrusted" until you allow
    # them once; this pre-approves it so it's clickable immediately.
    if command -v gio >/dev/null 2>&1; then
        gio set "$DESKTOP_DIR/pystore.desktop" metadata::trusted true 2>/dev/null || true
    fi
fi

# Refresh the desktop database so menus pick it up right away
if command -v update-desktop-database >/dev/null 2>&1; then
    update-desktop-database "$APPS_DIR" 2>/dev/null || true
fi

echo "🎉 Done! PyStore is installed as a native desktop app."
echo " - Look for 'PyStore' in your application menu/launcher, and/or"
echo " - Check your Desktop folder for a PyStore icon."
echo "Double-click it any time — it opens straight up, no browser, no scripts."
