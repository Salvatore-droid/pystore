const { app, BrowserWindow, Menu } = require('electron');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const os = require('os');
const http = require('http');

// PyStore's installed location (this is where install.sh / install-desktop-icon.sh
// set things up: a Django project + its own venv). Fall back to the folder right
// next to this Electron app, which is handy when running from source in dev.
const INSTALLED_DIR = path.join(os.homedir(), '.local', 'share', 'pystore');
const DEV_DIR = path.join(__dirname, '..');

function resolveProjectRoot() {
    if (fs.existsSync(path.join(INSTALLED_DIR, 'manage.py'))) return INSTALLED_DIR;
    if (fs.existsSync(path.join(DEV_DIR, 'manage.py'))) return DEV_DIR;
    return null;
}

const HOST = '127.0.0.1';
const PORT = '8765';
const URL = `http://${HOST}:${PORT}/`;

let mainWindow;
let djangoProcess;
let logStream;

function pythonBinFor(projectRoot) {
    const venvPython = path.join(projectRoot, 'venv', 'bin', 'python');
    if (fs.existsSync(venvPython)) return venvPython;
    return 'python3';
}

function startDjango(projectRoot) {
    const python = pythonBinFor(projectRoot);
    const logPath = path.join(app.getPath('userData'), 'pystore.log');
    logStream = fs.createWriteStream(logPath, { flags: 'a' });
    logStream.write(`\n--- Starting PyStore at ${new Date().toISOString()} ---\n`);

    djangoProcess = spawn(
        python,
        ['manage.py', 'runserver', `${HOST}:${PORT}`, '--noreload'],
        { cwd: projectRoot, detached: true, env: { ...process.env } }
    );

    djangoProcess.stdout.on('data', (d) => logStream.write(d));
    djangoProcess.stderr.on('data', (d) => logStream.write(d));
    djangoProcess.on('error', (err) => logStream.write(`Failed to start: ${err.message}\n`));
}

function waitForServer(timeoutMs, onReady, onTimeout) {
    const start = Date.now();
    const tryOnce = () => {
        const req = http.get(URL, (res) => {
            res.resume();
            onReady();
        });
        req.on('error', () => {
            if (Date.now() - start > timeoutMs) onTimeout();
            else setTimeout(tryOnce, 400);
        });
        req.setTimeout(1500, () => req.destroy());
    };
    tryOnce();
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1280,
        height: 820,
        minWidth: 900,
        minHeight: 600,
        backgroundColor: '#FDF7EF',
        autoHideMenuBar: true,
        icon: path.join(__dirname, 'icon.png'),
        title: 'PyStore',
        webPreferences: {
            contextIsolation: true,
            nodeIntegration: false,
        },
    });

    Menu.setApplicationMenu(null);
    mainWindow.loadFile(path.join(__dirname, 'loading.html'));

    const projectRoot = resolveProjectRoot();
    if (!projectRoot) {
        mainWindow.loadFile(path.join(__dirname, 'loading.html'), {
            search: 'error=notfound',
        });
        return;
    }

    startDjango(projectRoot);

    waitForServer(
        20000,
        () => mainWindow.loadURL(URL),
        () => mainWindow.loadFile(path.join(__dirname, 'loading.html'), { search: 'error=timeout' })
    );
}

function killDjango() {
    if (!djangoProcess) return;
    try {
        // Spawned detached so it's its own process group leader on Linux;
        // negative pid kills the whole group (safety net in case Django
        // ever spawns a child despite --noreload).
        process.kill(-djangoProcess.pid, 'SIGTERM');
    } catch (e) {
        try { djangoProcess.kill('SIGTERM'); } catch (_) { /* already gone */ }
    }
    djangoProcess = null;
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
    killDjango();
    if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', killDjango);
app.on('will-quit', killDjango);
process.on('exit', killDjango);
