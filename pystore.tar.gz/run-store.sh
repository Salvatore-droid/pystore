#!/usr/bin/env bash
# Launches PyStore: starts the Django server in the background (if it isn't
# already running) and opens it in your default browser.
# This is the script your desktop icon points to — you should never need to
# run "python manage.py runserver" by hand again.

set -e

# Resolve the real directory this script lives in, so it works no matter
# where it's launched from (double-click, terminal, symlink, etc.)
SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
cd "$SCRIPT_DIR"

HOST="127.0.0.1"
PORT="8000"
URL="http://${HOST}:${PORT}/"
PID_FILE="$SCRIPT_DIR/.pystore.pid"
LOG_FILE="$SCRIPT_DIR/.pystore.log"

# Prefer a virtualenv if one exists in the project folder
PYTHON="python3"
if [ -f "$SCRIPT_DIR/venv/bin/python" ]; then
    PYTHON="$SCRIPT_DIR/venv/bin/python"
elif [ -f "$SCRIPT_DIR/.venv/bin/python" ]; then
    PYTHON="$SCRIPT_DIR/.venv/bin/python"
fi

is_server_up() {
    curl -s -o /dev/null --max-time 1 "$URL" 2>/dev/null
}

open_browser() {
    if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$URL" >/dev/null 2>&1 &
    elif command -v gio >/dev/null 2>&1; then
        gio open "$URL" >/dev/null 2>&1 &
    else
        echo "Open this in your browser: $URL"
    fi
}

if is_server_up; then
    # Already running (e.g. from a previous launch) — just open the browser
    open_browser
    exit 0
fi

# Not running yet: start it in the background, detached from this terminal
nohup "$PYTHON" "$SCRIPT_DIR/manage.py" runserver "${HOST}:${PORT}" \
    > "$LOG_FILE" 2>&1 &
echo $! > "$PID_FILE"

# Wait for the server to come up (up to ~10 seconds) before opening the browser
for i in $(seq 1 20); do
    if is_server_up; then
        break
    fi
    sleep 0.5
done

open_browser
