from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from .models import InstalledApp
from .utils import PyStore
import json
import time
from threading import Thread
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

# Global dictionary to track installation progress
installation_progress = {}


def home(request):
    """Home page with search functionality"""
    if request.method == 'POST':
        app_name = request.POST.get('app_name', '').strip()
        if app_name.lower() == 'quit':
            return redirect('home')
        
        if not app_name:
            popular_apps = PyStore.get_popular_apps(limit=6)
            return render(request, 'index.html', {'error': 'Please enter an app name', 'popular_apps': popular_apps})
        
        search_results = PyStore.search(app_name)
        return render(request, 'results.html', {
            'app_name': app_name,
            'search_results': search_results,
            'has_results': len(search_results) > 0
        })
    
    # Get popular apps for home page
    popular_apps = PyStore.get_popular_apps(limit=6)
    return render(request, 'index.html', {
        'popular_apps': popular_apps
    })


def browse_apps(request):
    """Browse all available apps with pagination"""
    page = request.GET.get('page', 1)
    try:
        page = int(page)
    except ValueError:
        page = 1
    
    # Get popular apps (can be extended with pagination)
    all_apps = PyStore.get_popular_apps(limit=50)
    
    # Simple pagination
    per_page = 12
    start = (page - 1) * per_page
    end = start + per_page
    
    paginated_apps = all_apps[start:end]
    total_pages = (len(all_apps) + per_page - 1) // per_page
    
    return render(request, 'browse.html', {
        'apps': paginated_apps,
        'current_page': page,
        'total_pages': total_pages,
        'has_prev': page > 1,
        'has_next': page < total_pages,
        'prev_page': page - 1,
        'next_page': page + 1,
    })


def app_detail(request, app_id):
    """Display detailed information about an app"""
    try:
        app_details = PyStore.get_app_details(app_id)

        if not app_details:
            # Flathub might just be unreachable (no internet) rather than the
            # app not existing — if it's actually installed, build the page
            # from local data instead of hard-failing, so viewing/launching
            # an installed app never requires being online.
            if PyStore.is_app_installed(app_id):
                local_info = PyStore.get_installed_app_info(app_id) or {}
                app_details = {
                    'app_id': app_id,
                    'name': app_id.split('.')[-1],
                    'summary': 'Details unavailable offline — showing locally installed info.',
                    'description': '',
                    'version': local_info.get('version', 'Unknown'),
                    'icon_url': '',
                    'screenshots': [],
                    'url': '',
                    'developer_name': 'Unknown',
                    'categories': [],
                    'rating': 0,
                    'download_count': 0,
                    'is_installed': True,
                }
            else:
                messages.error(request, f"App '{app_id}' not found")
                return redirect('browse_apps')

        return render(request, 'app_detail.html', {
            'app': app_details
        })
    except Exception as e:
        logger.error(f"Error getting app details for {app_id}: {e}")
        messages.error(request, "Error loading app details")
        return redirect('browse_apps')


def install(request):
    """Handle app installation"""
    if request.method == 'POST':
        app_id = request.POST.get('app_id', '').strip()
        if app_id.lower() == 'quit':
            return redirect('home')
        
        if not app_id:
            return JsonResponse({'error': 'No app ID provided'}, status=400)
        
        install_id = f"{app_id}_{int(time.time())}"
        
        # Initialize progress tracking
        installation_progress[install_id] = {
            'status': 'initializing',
            'progress': 0,
            'message': 'Starting installation process...',
            'app_id': app_id,
            'logs': ['Starting installation process...'],
            'start_time': datetime.now().isoformat(),
            'current_stage': 'preparing',
            'stages': {
                'preparing': {'started': False, 'completed': False},
                'downloading': {'started': False, 'completed': False},
                'installing': {'started': False, 'completed': False},
                'finalizing': {'started': False, 'completed': False}
            },
            'metadata': {
                'size': None,
                'version': None
            },
            'download_progress': 0,
            'total_download_size': None,
            'downloaded_size': None,
            'install_details': {}
        }
        
        def install_thread():
            try:
                # Update progress - preparation started
                installation_progress[install_id].update({
                    'status': 'preparing',
                    'progress': 5,
                    'message': 'Preparing installation...',
                    'current_stage': 'preparing',
                    'stages': {
                        'preparing': {'started': True, 'completed': False},
                        'downloading': {'started': False, 'completed': False},
                        'installing': {'started': False, 'completed': False},
                        'finalizing': {'started': False, 'completed': False}
                    }
                })
                
                installation_progress[install_id]['logs'].append('Checking dependencies...')
                time.sleep(0.5)
                
                installation_progress[install_id].update({
                    'status': 'downloading',
                    'progress': 10,
                    'message': 'Starting download...',
                    'stages': {
                        'preparing': {'started': True, 'completed': True},
                        'downloading': {'started': True, 'completed': False},
                        'installing': {'started': False, 'completed': False},
                        'finalizing': {'started': False, 'completed': False}
                    }
                })
                
                # Phase 2: Download with real progress from flatpak
                def progress_callback(line):
                    current_data = installation_progress[install_id]
                    logs = current_data.get('logs', [])
                    logs.append(line)
                    
                    import re
                    
                    # Check for download progress
                    percent_match = re.search(r'(\d+)%', line)
                    if percent_match and 'Downloading' in line:
                        percent = int(percent_match.group(1))
                        scaled_progress = 10 + (percent * 0.6)  # Scale to 10-70%
                        installation_progress[install_id]['download_progress'] = percent
                        installation_progress[install_id]['progress'] = scaled_progress
                        installation_progress[install_id]['message'] = f'Downloading... {percent}%'
                    
                    # Check for installation progress
                    if 'Installing' in line and '%' in line:
                        install_match = re.search(r'Installing.*?(\d+)%', line)
                        if install_match:
                            install_percent = int(install_match.group(1))
                            scaled_progress = 70 + (install_percent * 0.2)  # Scale to 70-90%
                            installation_progress[install_id]['progress'] = scaled_progress
                            installation_progress[install_id]['message'] = f'Installing... {install_percent}%'
                            installation_progress[install_id]['current_stage'] = 'installing'
                            installation_progress[install_id]['status'] = 'installing'
                    
                    # Check for download size
                    size_match = re.search(r'Downloading (\d+\.?\d*) (\w+) of (\d+\.?\d*) (\w+)', line)
                    if size_match:
                        downloaded = size_match.group(1)
                        downloaded_unit = size_match.group(2)
                        total = size_match.group(3)
                        total_unit = size_match.group(4)
                        installation_progress[install_id]['downloaded_size'] = f"{downloaded} {downloaded_unit}"
                        installation_progress[install_id]['total_download_size'] = f"{total} {total_unit}"
                    
                    # Check for completion messages (success indicators)
                    if any(msg in line.lower() for msg in ['installation complete', 'installed', 'completed successfully']):
                        installation_progress[install_id]['logs'].append(f"✅ {line}")
                    
                    # Check for error messages
                    if any(err in line.lower() for err in ['error:', 'failed:', 'cannot', 'unable']):
                        installation_progress[install_id]['logs'].append(f"❌ {line}")
                    
                    # Update logs (keep last 100)
                    installation_progress[install_id]['logs'] = logs[-100:]
                    
                    # Update stages based on progress
                    progress = installation_progress[install_id]['progress']
                    stages = installation_progress[install_id]['stages']
                    
                    if progress >= 70 and not stages['installing']['started']:
                        stages['installing'] = {'started': True, 'completed': False}
                        installation_progress[install_id]['current_stage'] = 'installing'
                        installation_progress[install_id]['status'] = 'installing'
                    
                    if progress >= 90 and not stages['finalizing']['started']:
                        stages['finalizing'] = {'started': True, 'completed': False}
                        installation_progress[install_id]['current_stage'] = 'finalizing'
                        installation_progress[install_id]['status'] = 'finalizing'
                
                # Perform actual installation with real-time output
                success, output = PyStore.install_app_with_realtime_output(app_id, progress_callback)
                
                if not success:
                    # Installation failed
                    error_message = f"Installation failed: {output[:200]}..." if len(output) > 200 else output
                    installation_progress[install_id].update({
                        'status': 'failed',
                        'message': error_message,
                        'progress': 0,  # Reset progress on failure
                        'logs': installation_progress[install_id]['logs'] + [f'❌ ERROR: {error_message}']
                    })
                    return
                
                # Installation succeeded
                installation_progress[install_id].update({
                    'status': 'finalizing',
                    'progress': 95,
                    'message': 'Finalizing installation...',
                    'current_stage': 'finalizing',
                    'stages': {
                        'preparing': {'started': True, 'completed': True},
                        'downloading': {'started': True, 'completed': True},
                        'installing': {'started': True, 'completed': True},
                        'finalizing': {'started': True, 'completed': False}
                    }
                })
                
                # Get actual app metadata
                app_info = PyStore.get_installed_app_info(app_id)

                shortcut_ok, shortcut_detail = PyStore.create_desktop_shortcut(app_id)

                installation_progress[install_id]['logs'].extend([
                    'Creating desktop shortcut...' if shortcut_ok else f'⚠️ Could not create desktop shortcut: {shortcut_detail}',
                    'Updating application database...',
                    f"✅ Installation verified: {app_id}"
                ])
                
                if app_info:
                    installation_progress[install_id]['metadata'] = {
                        'size': app_info.get('size', '0 MB'),
                        'version': app_info.get('version', 'unknown')
                    }
                
                # Mark as completed
                installation_progress[install_id].update({
                    'status': 'completed',
                    'progress': 100,
                    'message': 'Installation complete!',
                    'stages': {
                        'preparing': {'started': True, 'completed': True},
                        'downloading': {'started': True, 'completed': True},
                        'installing': {'started': True, 'completed': True},
                        'finalizing': {'started': True, 'completed': True}
                    }
                })
                
            except Exception as e:
                logger.error(f"Installation error: {e}")
                installation_progress[install_id].update({
                    'status': 'failed',
                    'message': f'Unexpected error: {str(e)}',
                    'progress': 0,
                    'logs': installation_progress[install_id]['logs'] + [f'❌ FATAL ERROR: {str(e)}']
                })
        
        # Start installation in background thread
        thread = Thread(target=install_thread, daemon=True)
        thread.start()
        
        return render(request, 'installation_progress.html', {
            'install_id': install_id,
            'app_id': app_id
        })
    
    return redirect('home')


def installation_progress_api(request, install_id):
    """API endpoint to get installation progress"""
    if install_id not in installation_progress:
        return JsonResponse({'error': 'Installation not found'}, status=404)
    
    progress_data = installation_progress[install_id]
    return JsonResponse(progress_data)


def _parse_size_to_mb(size_str):
    """Convert a flatpak size string like '128.4 MB' or '1.2 GB' into MB (float)."""
    try:
        parts = size_str.strip().split()
        if len(parts) != 2:
            return 0.0
        value, unit = float(parts[0]), parts[1].upper()
        if unit.startswith('G'):
            return value * 1024
        if unit.startswith('K'):
            return value / 1024
        return value  # assume MB
    except (ValueError, AttributeError):
        return 0.0


def installed_apps(request):
    """Display list of installed apps"""
    if request.method == 'POST':
        # Bulk actions from the "Sync/Launch/Remove" buttons on the page
        selected_ids = request.POST.getlist('selected_ids')
        if 'uninstall' in request.POST:
            for app_id in selected_ids:
                success, msg = PyStore.uninstall_app(app_id)
                if success:
                    messages.success(request, f"Uninstalled {app_id}")
                else:
                    messages.error(request, f"Failed to uninstall {app_id}: {msg}")
        elif 'launch' in request.POST:
            for app_id in selected_ids:
                PyStore.run_app(app_id)
            messages.success(request, "Launching selected app(s)...")
        elif 'sync' in request.POST:
            messages.success(request, "Synced with system package list.")
        return redirect('installed_apps')

    try:
        raw_apps = PyStore.get_installed_apps()

        apps = []
        total_size_mb = 0.0
        for entry in raw_apps:
            app_id = entry.get('app_id', '')
            # flatpak list doesn't give us a friendly display name, so derive
            # one from the reverse-DNS app id, e.g. org.gnome.Calculator -> Calculator
            display_name = app_id.split('.')[-1] if app_id else 'Unknown App'
            size_str = entry.get('size', '0 MB')
            total_size_mb += _parse_size_to_mb(size_str)

            apps.append({
                'app_id': app_id,
                'name': display_name,
                'version': entry.get('version', 'Unknown'),
                'size': size_str,
                'status': 'up_to_date',
                'status_display': 'Up to date',
                'icon': 'cube',
                'icon_color': 'indigo',
            })

        context = {
            'apps': apps,
            'total_count': len(apps),
            'recent_count': 0,
            'update_count': 0,
            'total_size': f"{total_size_mb:,.1f} MB" if total_size_mb < 1024 else f"{total_size_mb / 1024:,.1f} GB",
        }
        return render(request, 'installed.html', context)
    except Exception as e:
        logger.error(f"Error getting installed apps: {e}")
        messages.error(request, "Error loading installed apps")
        return render(request, 'installed.html', {
            'apps': [],
            'total_count': 0,
            'recent_count': 0,
            'update_count': 0,
            'total_size': '0 MB',
        })


def uninstall_app(request, app_id):
    """Uninstall an application"""
    if request.method == 'POST':
        try:
            success, message = PyStore.uninstall_app(app_id)
            if success:
                messages.success(request, f"Successfully uninstalled {app_id}")
            else:
                messages.error(request, f"Failed to uninstall {app_id}: {message}")
        except Exception as e:
            logger.error(f"Error uninstalling {app_id}: {e}")
            messages.error(request, "Error uninstalling app")
        
        return redirect('installed_apps')
    
    return redirect('home')


def run_app(request, app_id):
    """Run an installed application"""
    try:
        success, detail = PyStore.run_app(app_id)
        if success:
            messages.success(request, f"Launching {app_id}...")
        else:
            messages.error(request, f"Failed to launch {app_id}: {detail}")
    except Exception as e:
        logger.error(f"Error running {app_id}: {e}")
        messages.error(request, "Error launching app")
    
    return redirect('installed_apps')


def create_desktop_shortcut_view(request, app_id):
    """Create a Desktop icon for a single installed app. Called via fetch()
    from the Installed page, so it returns JSON rather than redirecting."""
    if request.method != 'POST':
        return JsonResponse({'success': False, 'error': 'POST required'}, status=405)
    try:
        success, detail = PyStore.create_desktop_shortcut(app_id)
        if success:
            return JsonResponse({'success': True, 'path': detail})
        return JsonResponse({'success': False, 'error': detail}, status=400)
    except Exception as e:
        logger.error(f"Error creating desktop shortcut for {app_id}: {e}")
        return JsonResponse({'success': False, 'error': str(e)}, status=500)


def create_all_desktop_shortcuts_view(request):
    """Create Desktop icons for every installed app in one go."""
    if request.method != 'POST':
        return redirect('installed_apps')
    try:
        results = PyStore.create_desktop_shortcuts_for_all()
        created = len(results['created'])
        failed = len(results['failed'])
        if created and not failed:
            messages.success(request, f"Created {created} desktop icon(s) 🎉")
        elif created and failed:
            messages.success(request, f"Created {created} desktop icon(s), {failed} failed")
        elif failed:
            messages.error(request, f"Couldn't create desktop icons ({failed} failed)")
        else:
            messages.info(request, "No installed apps to create icons for")
    except Exception as e:
        logger.error(f"Error creating desktop shortcuts: {e}")
        messages.error(request, "Error creating desktop icons")
    return redirect('installed_apps')


def signup(request):
    """User signup view"""
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully!')
            return redirect('home')
    else:
        form = UserCreationForm()
    
    return render(request, 'signup.html', {'form': form})


def about(request):
    """About page"""
    return render(request, 'about.html')
