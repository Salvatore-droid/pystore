# store/utils.py - Complete updated file with Flathub API integration

import subprocess
import time
import os
import requests
from django.conf import settings
from typing import List, Dict, Optional
import logging

logger = logging.getLogger(__name__)

class FlathubAPI:
    """Interface for Flathub API v2"""
    BASE_URL = "https://flathub.org/api/v2"
    
    @staticmethod
    def search(query: str, locale: str = "en") -> List[Dict]:
        """
        Search for applications using Flathub API.
        
        Args:
            query: Search query string
            locale: Language locale (default: 'en')
            
        Returns:
            List of application dictionaries with metadata
        """
        try:
            url = f"{FlathubAPI.BASE_URL}/search"
            payload = {
                "query": query,
                "limit": 50
            }
            
            response = requests.post(url, json=payload, params={"locale": locale}, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            apps = []
            
            if "hits" in data:
                for result in data["hits"]:
                    app_data = {
                        'app_id': result.get('app_id', ''),
                        'name': result.get('name', ''),
                        'description': result.get('description', ''),
                        'version': result.get('current_release', {}).get('version', 'Unknown'),
                        'icon_url': FlathubAPI.get_app_icon_url(result.get('app_id', '')),
                        'is_installed': False,  # Will be checked later
                        'summary': result.get('summary', ''),
                        'category': result.get('categories', ['Other'])[0] if result.get('categories') else 'Other',
                        'rating': result.get('rating', 0),
                        'download_count': result.get('download_count', 0),
                    }
                    apps.append(app_data)
            
            return apps
        except requests.exceptions.RequestException as e:
            logger.error(f"Flathub API search error: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error in search: {e}")
            return []
    
    @staticmethod
    def get_app_details(app_id: str, locale: str = "en") -> Optional[Dict]:
        """
        Get detailed information about a specific application.
        
        Args:
            app_id: Application ID
            locale: Language locale (default: 'en')
            
        Returns:
            Dictionary with app details or None if not found
        """
        try:
            url = f"{FlathubAPI.BASE_URL}/appstream/{app_id}"
            response = requests.get(url, params={"locale": locale}, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data:
                return {
                    'app_id': data.get('id', app_id),
                    'name': data.get('name', ''),
                    'description': data.get('description', ''),
                    'summary': data.get('summary', ''),
                    'version': data.get('current_release', {}).get('version', 'Unknown'),
                    'icon_url': FlathubAPI.get_app_icon_url(app_id),
                    'screenshots': data.get('screenshots', []),
                    'url': data.get('url', ''),
                    'license': data.get('metadata_license', 'Unknown'),
                    'developer_name': data.get('developer_name', 'Unknown'),
                    'categories': data.get('categories', []),
                    'rating': data.get('rating', 0),
                    'download_count': data.get('download_count', 0),
                }
            return None
        except requests.exceptions.RequestException as e:
            logger.error(f"Flathub API details error for {app_id}: {e}")
            return None
        except Exception as e:
            logger.error(f"Unexpected error getting app details: {e}")
            return None
    
    @staticmethod
    def get_popular_apps(limit: int = 20, locale: str = "en") -> List[Dict]:
        """
        Get popular applications from Flathub.
        
        Args:
            limit: Number of apps to return
            locale: Language locale (default: 'en')
            
        Returns:
            List of popular application dictionaries
        """
        try:
            # Use search endpoint with empty query to get popular apps
            url = f"{FlathubAPI.BASE_URL}/search"
            payload = {
                "query": "",
                "limit": limit
            }
            
            response = requests.post(url, json=payload, params={"locale": locale}, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            apps = []
            
            if "hits" in data:
                for result in data["hits"][:limit]:
                    app_data = {
                        'app_id': result.get('app_id', ''),
                        'name': result.get('name', ''),
                        'description': result.get('description', ''),
                        'version': result.get('current_release', {}).get('version', 'Unknown') if isinstance(result.get('current_release'), dict) else 'Unknown',
                        'icon_url': FlathubAPI.get_app_icon_url(result.get('app_id', '')),
                        'is_installed': False,
                        'download_count': result.get('download_count', 0),
                    }
                    apps.append(app_data)
            
            return apps
        except requests.exceptions.RequestException as e:
            logger.error(f"Flathub API popular apps error: {e}")
            return []
        except Exception as e:
            logger.error(f"Unexpected error getting popular apps: {e}")
            return []
    
    @staticmethod
    def get_app_icon_url(app_id: str) -> str:
        """
        Get the icon URL for an application.
        
        Args:
            app_id: Application ID
            
        Returns:
            URL to the app icon or fallback avatar URL
        """
        try:
            if not app_id:
                return f"https://ui-avatars.com/api/?name=App&size=128&background=6366f1&color=fff"
            
            # Try multiple possible Flathub icon URLs
            possible_urls = [
                f"https://dl.flathub.org/repo/appstream/x86_64/icons/128x128/{app_id}.png",
                f"https://dl.flathub.org/media/{app_id}/icon-128x128.png",
                f"https://flathub.org/repo/appstream/x86_64/icons/128x128/{app_id}.png",
            ]
            
            # Return the first URL - browser will handle 404s
            return possible_urls[0]
        except Exception:
            app_name = app_id.split('.')[-1] if app_id else 'App'
            return f"https://ui-avatars.com/api/?name={app_name}&size=128&background=6366f1&color=fff"


class PyStore:
    """Main store interface combining Flathub API and local system management"""
    
    @staticmethod
    def search(query: str) -> List[Dict]:
        """
        Search for applications using Flathub API.
        
        Args:
            query: Search query string
            
        Returns:
            List of application dictionaries
        """
        if not query or query.lower() == 'quit':
            return []
        
        apps = FlathubAPI.search(query)
        
        # Check which apps are installed
        for app in apps:
            app['is_installed'] = PyStore.is_app_installed(app['app_id'])
        
        return apps
    
    @staticmethod
    def flatpak_search(app: str) -> List[Dict]:
        """
        Legacy search method for backward compatibility.
        Uses Flathub API instead of flatpak command.
        
        Args:
            app: Search query string
            
        Returns:
            List of application dictionaries
        """
        return PyStore.search(app)
    
    @staticmethod
    def get_app_details(app_id: str) -> Optional[Dict]:
        """
        Get detailed information about an application.
        
        Args:
            app_id: Application ID
            
        Returns:
            Dictionary with app details or None
        """
        details = FlathubAPI.get_app_details(app_id)
        
        if details:
            details['is_installed'] = PyStore.is_app_installed(app_id)
        
        return details
    
    @staticmethod
    def get_popular_apps(limit: int = 20) -> List[Dict]:
        """
        Get popular applications.
        
        Args:
            limit: Number of apps to return
            
        Returns:
            List of popular application dictionaries
        """
        apps = FlathubAPI.get_popular_apps(limit)
        
        # Check which apps are installed
        for app in apps:
            app['is_installed'] = PyStore.is_app_installed(app['app_id'])
        
        return apps
    
    @staticmethod
    def install_pyfiglet():
        try:
            subprocess.run(["sudo", "apt", "install", "python3-pyfiglet"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            text=True,
            check=True
            )
            return True
        except subprocess.CalledProcessError as e:
            return False, str(e)

    @staticmethod
    def get_app_icon_url(app_id: str, app_name: str = None) -> str:
        """Get icon URL for an app"""
        return FlathubAPI.get_app_icon_url(app_id)

    @staticmethod
    def is_app_installed(app_id: str) -> bool:
        """Check if an app is already installed"""
        try:
            result = subprocess.run(
                ["flatpak", "info", app_id],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except:
            return False

    @staticmethod
    def run_app(app_id: str):
        try:
            subprocess.run(["flatpak", "run", app_id], check=True)
            return True, "Launched"
        except subprocess.CalledProcessError as e:
            return False, str(e)
        except FileNotFoundError:
            return False, "flatpak isn't installed or isn't on PATH"

    @staticmethod
    def check_flatpak() -> bool:
        try:
            subprocess.run(["which", "flatpak"], 
                         stdout=subprocess.DEVNULL, 
                         stderr=subprocess.DEVNULL, 
                         text=True,
                         check=True)
            return True
        except subprocess.CalledProcessError:
            return False

    @staticmethod
    def run_command(command: List[str]) -> bool:
        try:
            subprocess.run(command, 
                         stdout=subprocess.DEVNULL, 
                         stderr=subprocess.DEVNULL, 
                         text=True, 
                         check=True)
            return True
        except subprocess.CalledProcessError as e:
            return False, str(e)

    @staticmethod
    def install_flatpak():
        results = []
        results.append(("Updating system...", PyStore.run_command(["sudo", "apt", "update"])))
        results.append(("Installing flatpak...", PyStore.run_command(["sudo", "apt", "install", "-y", "flatpak"])))
        results.append(("Adding flathub repository...", 
                      PyStore.run_command(["flatpak", "remote-add", "--if-not-exists", "flathub", "https://flathub.org/repo/flathub.flatpakrepo"])))
        return results

    @staticmethod
    def install_app(app_id: str):
        try:
            result = subprocess.run(["flatpak", "install", "-y", "flathub", app_id], 
                                capture_output=True, 
                                text=True,
                                check=True)
            return True, result.stdout
        except subprocess.CalledProcessError as e:
            return False, f"STDOUT: {e.stdout}\nSTDERR: {e.stderr}"

    @staticmethod
    def check_pyfiglet():
        try:
            subprocess.run(["pip", "list", "|", "grep", "pyfiglet"],
                         stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL,
                         text=True,
                         check=True)
            return True
        except subprocess.CalledProcessError as e:
            return False, str(e)

    @staticmethod
    def check_flatpak_working():
        """Verify Flatpak can install apps"""
        try:
            test_app = "org.gnome.Calculator"  # A small, reliable test app
            result = subprocess.run(["flatpak", "install", "-y", "flathub", test_app],
                                capture_output=True,
                                text=True)
            if result.returncode == 0:
                return True, "Flatpak working correctly"
            return False, f"Test failed: {result.stderr}"
        except Exception as e:
            return False, str(e)

    @staticmethod
    def _flatpak_export_dirs() -> List[str]:
        """Where Flatpak exports .desktop files for installed apps — checks
        both user-level and system-level install locations since PyStore's
        own install command doesn't force one or the other."""
        home = os.path.expanduser("~")
        return [
            os.path.join(home, ".local", "share", "flatpak", "exports", "share", "applications"),
            "/var/lib/flatpak/exports/share/applications",
        ]

    @staticmethod
    def find_exported_desktop_file(app_id: str) -> Optional[str]:
        """Locate the .desktop file Flatpak already generated for this app
        when it was installed. Flatpak app IDs are reverse-DNS
        (org.gnome.Calculator), and it names the file `<app_id>.desktop`."""
        for export_dir in PyStore._flatpak_export_dirs():
            candidate = os.path.join(export_dir, f"{app_id}.desktop")
            if os.path.isfile(candidate):
                return candidate
        return None

    @staticmethod
    def create_desktop_shortcut(app_id: str, app_name: str = None) -> tuple:
        """Create a real Desktop icon for an installed Flatpak app.

        Flatpak automatically registers apps in the system application menu,
        but it does NOT put an icon on the Desktop itself — this does that
        part, by copying (or, if needed, building) the app's .desktop file
        into ~/Desktop, so it opens with a double-click, no PyStore required.
        """
        try:
            desktop_dir = os.environ.get("XDG_DESKTOP_DIR") or os.path.join(os.path.expanduser("~"), "Desktop")
            os.makedirs(desktop_dir, exist_ok=True)
            target = os.path.join(desktop_dir, f"{app_id}.desktop")

            source = PyStore.find_exported_desktop_file(app_id)
            if source:
                with open(source, "r", encoding="utf-8", errors="ignore") as f:
                    content = f.read()
                # Exported files sometimes reference the app's own DBus
                # activation rather than a plain runnable Exec= line; make
                # sure Exec explicitly runs through flatpak so the icon
                # always works regardless of how the export was generated.
                if "Exec=" not in content:
                    content += f"\nExec=flatpak run {app_id}\n"
            else:
                # No export found (unusual, but be resilient) — build a
                # minimal working shortcut ourselves. Flatpak also exports
                # icons into the standard icon theme path under the app_id,
                # so referencing Icon=<app_id> resolves correctly.
                display_name = app_name or app_id.split('.')[-1]
                content = (
                    "[Desktop Entry]\n"
                    "Type=Application\n"
                    f"Name={display_name}\n"
                    f"Exec=flatpak run {app_id}\n"
                    f"Icon={app_id}\n"
                    "Terminal=false\n"
                    "Categories=Application;\n"
                )

            with open(target, "w", encoding="utf-8") as f:
                f.write(content)
            os.chmod(target, 0o755)

            # GNOME/Nautilus treats new .desktop files on the Desktop as
            # "untrusted" until manually allowed once; pre-approve it so it's
            # clickable immediately instead of showing a warning dialog.
            try:
                subprocess.run(
                    ["gio", "set", target, "metadata::trusted", "true"],
                    capture_output=True, timeout=5
                )
            except (FileNotFoundError, subprocess.TimeoutExpired):
                pass

            return True, target
        except Exception as e:
            logger.error(f"Error creating desktop shortcut for {app_id}: {e}")
            return False, str(e)

    @staticmethod
    def create_desktop_shortcuts_for_all() -> Dict:
        """Create Desktop icons for every currently-installed app in one go."""
        results = {"created": [], "failed": []}
        for app in PyStore.get_installed_apps():
            app_id = app.get("app_id")
            if not app_id:
                continue
            success, detail = PyStore.create_desktop_shortcut(app_id)
            if success:
                results["created"].append(app_id)
            else:
                results["failed"].append({"app_id": app_id, "error": detail})
        return results

    @staticmethod
    def get_installed_apps():
        try:
            result = subprocess.run(
                ["flatpak", "list", "--columns=application,version,size"],
                capture_output=True,
                text=True,
                check=True
            )
            
            apps = []
            for line in result.stdout.split('\n'):
                if not line.strip():
                    continue
                parts = line.split('\t')
                if len(parts) < 3:
                    continue
                app_id = parts[0].strip()
                # Some flatpak versions print a header row even when piped
                # (e.g. "Application ID"); skip it defensively.
                if app_id.lower() in ('application', 'application id', 'name'):
                    continue
                apps.append({
                    'app_id': app_id,
                    'version': parts[1].strip(),
                    'size': parts[2].strip(),
                })
            return apps
        except (subprocess.CalledProcessError, FileNotFoundError, OSError) as e:
            return []

    @staticmethod
    def get_installed_app_info(app_id: str) -> Optional[Dict]:
        """Get actual installed app information"""
        try:
            result = subprocess.run(
                ['flatpak', 'info', app_id],
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                return None
                
            info = {}
            for line in result.stdout.split('\n'):
                if ':' in line:
                    key, val = line.split(':', 1)
                    info[key.strip().lower()] = val.strip()
            
            return info
        except:
            return None

    @staticmethod
    def uninstall_app(app_id: str):
        try:
            result = subprocess.run(
                ["flatpak", "uninstall", "-y", app_id],
                capture_output=True,
                text=True,
                check=True
            )
            # Best-effort cleanup of any Desktop icon we created for this
            # app — leaving it behind would just be a dead shortcut now.
            try:
                desktop_dir = os.environ.get("XDG_DESKTOP_DIR") or os.path.join(os.path.expanduser("~"), "Desktop")
                shortcut = os.path.join(desktop_dir, f"{app_id}.desktop")
                if os.path.isfile(shortcut):
                    os.remove(shortcut)
            except Exception:
                pass
            return True, result.stdout
        except subprocess.CalledProcessError as e:
            return False, e.stderr

    @staticmethod
    def install_app_with_progress(app_id: str, progress_callback=None):
        try:
            process = subprocess.Popen(
                ["flatpak", "install", "-y", "--verbose", "flathub", app_id],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            while True:
                output = process.stdout.readline()
                if output == '' and process.poll() is not None:
                    break
                if output:
                    if progress_callback:
                        progress_callback(output.strip())
            
            if process.returncode == 0:
                return True, "Installation completed successfully"
            else:
                return False, f"Installation failed with return code {process.returncode}"
        except Exception as e:
            return False, str(e)

    @staticmethod
    def humanize_flatpak_line(line: str) -> Optional[str]:
        """
        Convert a raw flatpak output line into a friendly user-facing message.
        Returns None if the line should be silently skipped (debug noise).
        """
        import re
        l = line.strip()
        if not l:
            return None

        # Skip verbose debug lines (D-Bus, ostree internals, HTTP headers, etc.)
        skip_prefixes = (
            'F: ', 'D: ', 'W: ', 'I: ', 'E: ',
            'bwrap:', 'dbus-proxy:', 'ostree',
            'Downloading: https', 'HEAD ', 'GET ',
            'soup', 'GLib', 'libflatpak',
        )
        skip_fragments = (
            'debug:', 'object_store', 'delta superblock',
            'commit checksum', 'fetching', 'resolving', 'commit ',
            '.dconf', 'XDG_', 'LD_PRELOAD', 'sandbox',
            'static delta', 'zlib ', 'HTTP/1', 'HTTP/2',
        )
        low = l.lower()
        if any(l.startswith(p) for p in skip_prefixes):
            return None
        if any(f in low for f in skip_fragments):
            return None

        # Translate common flatpak messages to friendly text
        if re.search(r'downloading.*?(\d+\.?\d*\s*\w+B)', l, re.I):
            m = re.search(r'(\d+\.?\d*\s*[KMG]?B)', l, re.I)
            size = m.group(1) if m else ''
            return f"Downloading files{' — ' + size if size else ''}…"
        if re.search(r'installing.*?(\d+)%', l, re.I):
            pct = re.search(r'(\d+)%', l).group(1)
            return f"Installing… {pct}% done"
        if 'already installed' in low:
            return "This app is already installed on your system."
        if 'no updates' in low:
            return "Everything is already up to date."
        if re.search(r'install(ing|ed).*runtime', l, re.I):
            return "Installing required runtime components…"
        if 'verifying' in low or 'checksum' in low:
            return "Verifying download integrity…"
        if 'unpacking' in low or 'extracting' in low:
            return "Unpacking application…"
        if re.search(r'error:', l, re.I):
            return f"Error: {l.split(':', 1)[-1].strip()}"
        if re.search(r'(complete|success|finished)', low):
            return "Installation finished successfully!"

        # If it's a short readable line (no hex hashes, no slashes galore), pass it through
        if len(l) < 120 and '/' not in l[:10] and not re.search(r'[0-9a-f]{20,}', l):
            return l

        return None  # Default: skip unrecognised verbose lines

    @staticmethod
    def install_app_with_realtime_output(app_id: str, callback=None):
        """Install app with real-time output capturing"""
        try:
            process = subprocess.Popen(
                ["flatpak", "install", "-y", "flathub", app_id],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                universal_newlines=True
            )
            
            output_lines = []
            return_code = None
            
            while True:
                line = process.stdout.readline()
                if line == '' and process.poll() is not None:
                    return_code = process.poll()
                    break
                if line:
                    line = line.strip()
                    output_lines.append(line)
                    if callback:
                        friendly = PyStore.humanize_flatpak_line(line)
                        if friendly:
                            callback(friendly)
            
            # Check for success indicators in output
            if return_code == 0:
                # Also check if there are any error messages in the output
                error_indicators = ['error:', 'failed:', 'cannot install', 'unable to']
                last_lines = ' '.join(output_lines[-10:]).lower()
                
                if any(indicator in last_lines for indicator in error_indicators):
                    return False, "Installation completed with warnings: " + ' '.join(output_lines[-3:])
                
                return True, "Installation completed successfully"
            else:
                error_msg = f"Flatpak returned error code {return_code}"
                if output_lines:
                    error_msg += ": " + output_lines[-1]
                return False, error_msg
                
        except subprocess.TimeoutExpired:
            process.kill()
            return False, "Installation timed out"
        except Exception as e:
            return False, str(e)
