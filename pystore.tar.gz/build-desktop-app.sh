#!/usr/bin/env bash
# Builds PyStore into a real, double-clickable desktop app (an AppImage).
# Run this ONCE. It needs Node.js + npm (just for the build itself — the
# AppImage it produces doesn't need Node installed to run).

set -e

SCRIPT_DIR="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")" && pwd)"
ELECTRON_DIR="$SCRIPT_DIR/electron"

if ! command -v npm >/dev/null 2>&1; then
    echo "npm is required to build the desktop app (only for this one-time build step)."
    echo "  Debian/Ubuntu: sudo apt install nodejs npm"
    echo "  Fedora:        sudo dnf install nodejs npm"
    echo "  Arch:          sudo pacman -S nodejs npm"
    exit 1
fi

cd "$ELECTRON_DIR"
echo "==> Installing build tools (this downloads Electron, ~120MB — grab a coffee)"
npm install

echo "==> Building the AppImage"
npm run dist

APPIMAGE=$(find "$ELECTRON_DIR/dist" -maxdepth 1 -name "*.AppImage" | head -n 1)
if [ -z "$APPIMAGE" ]; then
    echo "Build finished but no AppImage was found in $ELECTRON_DIR/dist — check the output above for errors."
    exit 1
fi
chmod +x "$APPIMAGE"

# AppImages normally mount themselves via FUSE when double-clicked. Most
# distros don't ship libfuse2 by default anymore, which makes the app
# silently do nothing when clicked (no error, no dialog — it just fails to
# mount). To make this a sure bet regardless of what's installed, we extract
# the AppImage once here and point the desktop icon at the extracted binary
# instead, so nothing at runtime depends on FUSE at all.
echo "==> Extracting the app so it doesn't depend on FUSE at runtime"
cd "$ELECTRON_DIR/dist"
rm -rf squashfs-root pystore-app
./"$(basename "$APPIMAGE")" --appimage-extract >/dev/null
rm -rf pystore-app
mv squashfs-root pystore-app
chmod +x "$ELECTRON_DIR/dist/pystore-app/AppRun"

echo
echo "Built: $APPIMAGE"
echo "Extracted, runnable copy: $ELECTRON_DIR/dist/pystore-app/AppRun"
echo "Next, run ./install-desktop-icon.sh — it will point your desktop icon at"
echo "the extracted app, so it opens reliably with no FUSE dependency."
